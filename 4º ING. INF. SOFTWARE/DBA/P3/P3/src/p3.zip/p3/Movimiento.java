package p3;

public enum Movimiento {
    NORTE,
    SUR,
    ESTE,
    OESTE,
    NORESTE,
    NOROESTE,
    SURESTE,
    SUROESTE
}
