/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package p3;

/**
 *
 * @author carmenxufdz
 */
public interface AgenteInterface {
    public void iniciarComportamiento();
    public Entorno getEntorno();
    public String next();
    public String Energia();
}
